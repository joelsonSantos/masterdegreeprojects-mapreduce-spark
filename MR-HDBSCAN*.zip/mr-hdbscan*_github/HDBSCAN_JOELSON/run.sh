# Original 
cp /home/joelson/Dropbox/Mestrado/MR-HDBSCAN*/HDBSCAN_JOELSON/MR-HDBSCANStar.jar /usr/local/spark/jars/MR-HDBSCANStar.jar
/usr/local/spark/bin/spark-submit --class main.Main /usr/local/spark/jars/MR-HDBSCANStar.jar file=/home/joelson/bases/Iris minPts=4 minClSize=4 compact=true processing_units=50 k=0.2 clusterName=local


# Original 
#cp /home/joelson/Dropbox/Mestrado/MR-HDBSCAN*/HDBSCAN_JOELSON/MR-HDBSCANStar.jar /usr/local/spark/jars/MR-HDBSCANStar.jar
#/usr/local/spark/bin/spark-submit --class main.Main /usr/local/spark/jars/MR-HDBSCANStar.jar file=/home/joelson/bases/big minPts=4 minClSize=4 compact=true processing_units=1000 k=0.1 clusterName=local


